﻿namespace visualizer
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnmodel = new Button();
            btnview = new Button();
            btninfo = new Button();
            lblinfo = new Label();
            SuspendLayout();
            // 
            // btnmodel
            // 
            btnmodel.Location = new Point(12, 279);
            btnmodel.Name = "btnmodel";
            btnmodel.Size = new Size(209, 23);
            btnmodel.TabIndex = 0;
            btnmodel.Text = "Зареждане на модел";
            btnmodel.UseVisualStyleBackColor = true;
            btnmodel.Click += button1_Click;
            // 
            // btnview
            // 
            btnview.Location = new Point(227, 279);
            btnview.Name = "btnview";
            btnview.Size = new Size(209, 23);
            btnview.TabIndex = 1;
            btnview.Text = "Автоматично оглеждане на модел";
            btnview.UseVisualStyleBackColor = true;
            btnview.Click += btnview_Click;
            // 
            // btninfo
            // 
            btninfo.Location = new Point(442, 279);
            btninfo.Name = "btninfo";
            btninfo.Size = new Size(209, 23);
            btninfo.TabIndex = 2;
            btninfo.Text = "Информация";
            btninfo.UseVisualStyleBackColor = true;
            // 
            // lblinfo
            // 
            lblinfo.AutoSize = true;
            lblinfo.Location = new Point(12, 261);
            lblinfo.Name = "lblinfo";
            lblinfo.Size = new Size(84, 15);
            lblinfo.TabIndex = 3;
            lblinfo.Text = "Информация:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(666, 314);
            Controls.Add(lblinfo);
            Controls.Add(btninfo);
            Controls.Add(btnview);
            Controls.Add(btnmodel);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnmodel;
        private Button btnview;
        private Button btninfo;
        private Label lblinfo;
    }
}
