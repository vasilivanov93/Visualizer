﻿namespace visualizer
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            glControl1 = new OpenTK.GLControl();
            btnmodel = new Button();
            btnview = new Button();
            btninfo = new Button();
            lblinfo = new Label();
            SuspendLayout();
            // 
            // glControl1
            // 
            glControl1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            glControl1.BackColor = Color.Black;
            glControl1.Location = new Point(13, 65);
            glControl1.Margin = new Padding(4, 3, 4, 3);
            glControl1.Name = "glControl1";
            glControl1.Size = new Size(677, 250);
            glControl1.TabIndex = 4;
            glControl1.VSync = false;
            glControl1.AutoSizeChanged += glControl1_AutoSizeChanged;
            glControl1.Load += glControl1_Load;
            glControl1.Paint += glControl1_Paint;
            glControl1.Resize += glControl1_AutoSizeChanged;
            // 
            // btnmodel
            // 
            btnmodel.Location = new Point(13, 340);
            btnmodel.Name = "btnmodel";
            btnmodel.Size = new Size(209, 23);
            btnmodel.TabIndex = 0;
            btnmodel.Text = "Зареждане на модел";
            btnmodel.UseVisualStyleBackColor = true;
            btnmodel.Click += button1_Click;
            // 
            // btnview
            // 
            btnview.Location = new Point(228, 340);
            btnview.Name = "btnview";
            btnview.Size = new Size(209, 23);
            btnview.TabIndex = 1;
            btnview.Text = "Автоматично оглеждане на модел";
            btnview.UseVisualStyleBackColor = true;
            btnview.Click += btnview_Click;
            // 
            // btninfo
            // 
            btninfo.Location = new Point(443, 340);
            btninfo.Name = "btninfo";
            btninfo.Size = new Size(209, 23);
            btninfo.TabIndex = 2;
            btninfo.Text = "Информация";
            btninfo.UseVisualStyleBackColor = true;
            // 
            // lblinfo
            // 
            lblinfo.AutoSize = true;
            lblinfo.Location = new Point(13, 322);
            lblinfo.Name = "lblinfo";
            lblinfo.Size = new Size(84, 15);
            lblinfo.TabIndex = 3;
            lblinfo.Text = "Информация:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(703, 376);
            Controls.Add(lblinfo);
            Controls.Add(btninfo);
            Controls.Add(btnview);
            Controls.Add(btnmodel);
            Controls.Add(glControl1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private OpenTK.GLControl glControl1;
        private Button btnmodel;
        private Button btnview;
        private Button btninfo;
        private Label lblinfo;
    }
}
